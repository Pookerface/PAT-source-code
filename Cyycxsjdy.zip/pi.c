/*����pi�Ľ���ֵ��ʹ�ù�ʽpi = 16��1/5-1/��3*5^3)+1/(5*5^5)-1/(7*5^7)+...)-4*(1/239-1/(3*239^3)+1/(5*239^5)-1/(7*239^7)+...)
��ȷ��С�����8λ*/ 
#include<stdio.h>
int main()
{
	int i,j,k,sign;
	double n,d,sa=0,sb=0,eps,e=1e-8;
	eps = e/16.0;
	for(i=0,d=1;d>eps;i++){
		sign = i%2 == 0? 1:-1;
		k = 2*i+1;
		if(i==0) n=5.0;
		else{
			n *= 5;
			n *= 5;
		}
		d   = 1.0/(n*k);
		sa += d*sign;
	}
	eps = e/4.0;
	for(i=0,d=1;d>eps;i++){
		sign = i%2 == 0? 1:-1;
		k = 2*i+1;
		if(i==0) n=239.0;
		else{
			n *= 239;
			n *= 239;	
		}
		d   = 1.0/(n*k);
		sb += d*sign;
	} 
	printf("%.8f\n",16*sa-4*sb);
	return 0;
}
