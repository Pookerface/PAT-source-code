#include<stdio.h>
int main(){
	int A,Da,B,Db;
	int Pa=0,Pb=0;
	scanf("%d %d %d %d",&A,&Da,&B,&Db);
	for(int i=0;A != 0||B != 0;i++){
		if(A%10==Da){
			Pa = Pa*10+Da;
		}
		A = A/10;
		if(B%10==Db){
			Pb = Pb*10+Db;
		}
		B = B/10;
	}
	printf("%d",Pa+Pb);
}
