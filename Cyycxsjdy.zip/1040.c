#include<stdio.h>
#define N 100000
int main(){
	char zimu[N+1];
	int p = 0, pa = 0, pat = 0;
	gets(zimu);
	for(int i =0;zimu[i] != '\0';i++){
		if(zimu[i] == 'P'){
			p++;
		}
		else if(zimu[i] == 'A'){
			pa += p;
			pa %= 1000000007;
		}
		else if(zimu[i] == 'T'){
			pat += pa;
			pat %= 1000000007;
		}
	}
	printf("%d",pat);
	return 0;
}
