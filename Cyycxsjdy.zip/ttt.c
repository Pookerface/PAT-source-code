#include<stdio.h>
int main()
{
	int st,len,c1,c2;
	int i=35;
//	scanf("%d %d %d %d",&st,&len,&c1,&c2);
//	for(i=0; i<st-1; i++)
//	{
//		putchar(' ');
//	}
//	putchar(c1);
//	for(i=1; i<len-1; i++)
//	{
//		putchar(c2);
//	}
//	putchar(c1);
//	putchar('\n');
	putchar(i);
	return 0;
}
