#include<stdio.h>
#include<stdlib.h>
int cmp(const void *a,const void *b){
	int m = *(int *)a;
	int n = *(int *)b;
//	return m-n;
	return n-m;
}
int main(){
	int n[10];
	for(int i=0;i<10;i++){
		scanf("%d",&n[i]);
	}
	qsort(n,10,sizeof(n[0]),cmp);
	for(int i=0;i<10;i++){
		printf("%d ",n[i]);
	}
	return 0;
}
