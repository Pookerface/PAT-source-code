#include<stdio.h>
#include<stdlib.h>
int cmp(const void *a, const void *b) {
    return *(int *) a - *(int *) b;
}
int main(){
	int N,sum = 0,max = 0;
	scanf("%d",&N);
	long num[N];
	long sort[N];
	long result[N];
	for(int i = 0;i<N;i++){
		scanf("%ld",&num[i]);
		sort[i] = num[i];
	}
	qsort(sort, N, sizeof(result[0]), cmp);
	for(int i =0;i<N;i++){
		if(num[i]==sort[i]&&sort[i]>max){
			result[sum++] = num[i];
		}
		if(num[i] > max){
			max = num[i];
		}
	}
	printf("%d\n",sum);
	for(int j = 0;j<sum;j++){
		if(j!=0) printf(" ");
		printf("%ld",result[j]);
	}
	printf("\n");
	return 0;
}
