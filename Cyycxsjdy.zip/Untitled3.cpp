#include<stdio.h>
int Day(int m,int year){
	int Day = 0;
	switch(m){
		case 1:case 3:case 5:case 7:case 8:case 10:case 12:
			Day = 31;break;
		case 2:
			if(Is_Run(year))
				Day = 29;
			else Day=28;
			break;
		case 4:case 6:case 9:case 11:
			Day = 30;
			break;
			
	}
}
int Is_Run(int year){
	if(year%4==0||year%40==0||year%400==0)
	{
		return 1;
	}
	return 0;
}
int sum(int m,int year){
	int sum = 0;
	switch(m){
		case 1: sum = 31;break; case 2:sum = 60;break;
		case 3: sum = 91;break; case 4:sum = 121;break;
		case 5: sum =152;break; case 6:sum = 182;break;
		case 7: sum =213;break; case 8:sum = 245;break;
		case 9: sum =275;break; case 10:sum = 306:break;
		case 11:sum = 336:break; case 12:sum = 367;break;
	}
//	sum += d; 
	if(!Is_Run(year)){
		if(m==1||(m==2&&(d<28||d==28))){
			;
		}
		else{
			sum = sum-1;
		}
	}
}
int main(){
	int y1,m1,d1,n,y2,m2,d2,x;
	int i,n_temp,sum = 0;
	scanf("y1:%d m1:%d d1:%d n:%d",&y1,&m1,&d1,&n);
	if(n<sum(m1-1,y1)+d1){
		for(i=m1;i>=1;i--){
			sum += sum(i,y1);
			if(sum>n) break;
		}
		m2 = i+1;
		d2 = n -sum()
	}
}
