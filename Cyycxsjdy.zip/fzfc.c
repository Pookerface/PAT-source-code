#include<stdio.h>
#include<string.h>
#define N 80
int main(){
	int len,i,j;
	char s[N+1];
	gets(s);
	len = strlen(s);
	for(i=len;i>=0;i--){
		if(s[i] == ' '){
			for(j=i+1;s[j] != ' '&& s[j] != '\0';j++){
				printf("%c",s[j]);
			}
			printf(" ");
		}
		if(i==0){
			for(j=i;s[j] != ' ';j++){
				printf("%c",s[j]);
			}
			break;
		}
	}
	return 0;
}
