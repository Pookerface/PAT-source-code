#include<stdio.h>
#include <stdlib.h>
void InsertSort_one(int num, int *n,int N){
	int j;
	int key    = n[num];
	for(j  = num-1;j>=0&&n[j]>key;j--){
		n[j+1] = n[j];
	}
	n[j+1] = key;
	for(int i = 0;i<N-1;i++){
		printf("%d ",n[i]);
	}
	printf("%d",n[N-1]);
}
int cmp(const void *a, const void *b) {
    return *(int *) a - *(int *) b;
}
int main(){
	int N;
	scanf("%d",&N);
	int old[N];
	int mid[N];
	int Isinsert = 1;
	int index=0;
	
	for(int i = 0;i<N;i++){
		scanf("%d",&old[i]);
	}
	for(int i = 0;i<N;i++){
		scanf("%d",&mid[i]);
	}
	for (int i = 0; i < N; i++){
        if (mid[i] < mid[i - 1]){
            index = i;
            break;
        }
    }
	for (int i = index; i < N; i++) {
        if (old[i] != mid[i]) {
            Isinsert = 0;
            break;
        }
    }
    if(Isinsert){
    	printf("Insertion Sort\n");
        InsertSort_one(index, mid,N);
	}
	else{
		printf("Merge Sort\n");
		int len  = 2,flag = 0;
		while(1){
			int i = 0;
			int time = N/len,m=0;
			for(i=1;i<=time;i++){
				qsort(&old[m],len,sizeof(old[0]),cmp);
				m += len;
			}
			if(m<N){
				qsort(&old[m],N-m,sizeof(old[0]),cmp);
				if(flag == 1) break;
			}
			for(i =0;i<N&&old[i]==mid[i];i++){
				if(i == N-1) flag = 1;
			}
			len *= 2;
		}
		for(int i = 0;i<N-1;i++){
			printf("%d ",old[i]);
	    }
		printf("%d",old[N-1]);
	}
	return 0;
}










