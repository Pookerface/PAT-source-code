#include<stdio.h>
#include<string.h>
#define N 10
//void strcpy1(char  *s1,char *s2){
//	int i;
//	for(i=0;s2[i] != '\0';i++){
//		s1[i] = s2[i];
//	}
//	for(;s1[i]!='\0';i++){
//		s1[i] = '\0';
//	}
//} 

int main(){
	int n,i=0;
	int min=100,max=0;
	char xm_min[N+1],xm_max[N+1],xh_min[N+1],xh_max[N+1];
	scanf("%d",&n);
//	getchar();
	while(i<n){
		char xm[N+1],xh[N+1];
		int s;
		scanf("%s %s %d",xm,xh,&s);
//		getchar();
		if(min>s){
			min = s;
			strcpy(xm_min,xm);
			strcpy(xh_min,xh);
		}
		if(max<s){
			max = s;
			strcpy(xm_max,xm);
			strcpy(xh_max,xh);	
		}
		i++;
	}
	printf("%s %s\n",xm_max,xh_max);
	printf("%s %s\n",xm_min,xh_min);
	return 0;
}
