#include<stdio.h>
#define N 100
int main(){

	
	int n;//,pp,pt,np=0,nt=0,n1=0,n2=0,n3=0;
	int i=0;

	scanf("%d",&n);
    getchar();

	while(i<n){
		int j=0,p=0;
		int pp=0,pt=0,np=0,nt=0,n1=0,n2=0,n3=0;
		char s[N+1];
		gets(s);
		for(j=0;s[j]!='\0';j++){
			if(s[j]=='A'&&np==0){
				n1++;
			}
			else if(s[j]=='P'&&np==0){
				np++;
				pp = j;	
			}
			else if(s[j]=='A'&&np==1&&nt==0){
				n2++;
			}
			else if(s[j]=='T'&&nt==0){
				nt++;
				pt = j;
			}
			else if(s[j]=='A'&&nt==1){
				n3++;
			}
			else{
				p=1;
				break;
			}
		}
		if(pt>pp&&np==1&&nt==1&&n1*n2==n3&&p==0&&n1+n2+n3!=0){
			printf("YES\n");
		}
		else{
			printf("NO\n");
		}
		i++;
	}
	return 0;
}
