#include<stdio.h>
int main(){
	int x,m,num_,x_,sign,sum=1;
	int i,j;
	double eps,d,sin_x=0;
	scanf("%d %d",&x,&m);
//	if(x<-10||x==-10||x>10||x==10||m<1||m==1||m>12||m==12){
//		return 0;
//	}
	for(i=0;i<m;i++){
		sum *= 10;
	}
	eps   = 1.0/sum;
//	printf("%.5f\n",eps);
	for(i=1;d>eps;i++){
		sign = i%2==0? -1:1;
		if(i==1){
			num_ = 1;
			x_   = x;
		}
		else{
			for(j=2*i-1;j>2*(i-1)-1;j--){
			num_ *= j;
			x_  *= x;
		}
		}
	
		d = x_*1.0/num_;
		sin_x += s
		
		
		
		
		ign*d;
	}
	printf("%.12f\n",sin_x);
	return 0;
}








