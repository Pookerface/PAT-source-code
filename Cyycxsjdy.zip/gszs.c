#include<stdio.h>

int main(){
	int n,i;
	scanf("%d",&n);
	if(n/100!=0){
		i=0;
		while(i<n/100){
			printf("B");
			i++;
		}
		n %= 100;
	}
	if(n/10!=0){
		i=0;
		while(i<n/10){
			printf("S");
			i++;
		}
		n %= 10;
	}
	if(n>0){
		for(i=1;i<=n;i++){
			printf("%d",i);
		}
	}
	printf("\n");
	return 0;
}
