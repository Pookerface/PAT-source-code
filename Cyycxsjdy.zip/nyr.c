/*��֪ĳ��ĳ��ĳ�������ڼ�������ǰn(0<n<3000)��������պ����ڡ�����ӱ�׼�����ļ��ж����ĸ�����y1��m1��d1��n��
�ֱ��ʾ��֪�������պ�n���ڱ�׼���������ĸ�����y2��m2��d2,x,�ֱ��ʾ����������պ�����*/
#include<stdio.h>
int Is_Run(int year);
int Day(int m,int year){
	int Day = 0;
	switch(m){
		case 1:case 3:case 5:case 7:case 8:case 10:case 12:
			Day = 31;break;
		case 2:
			if(Is_Run(year))
				Day = 29;
			else Day=28;
			break;
		case 4:case 6:case 9:case 11:
			Day = 30;
			break;
			
	}
	return Day;
}
int Is_Run(int year){
	if(year%4==0||year%40==0||year%400==0)
	{
		return 1;
	}
	return 0;
}
int Sum(int m,int year){
	int sum = 0;
	switch(m){
		case 1: sum = 31;break; case 2:sum = 60;break;
		case 3: sum = 91;break; case 4:sum = 121;break;
		case 5: sum =152;break; case 6:sum = 182;break;
		case 7: sum =213;break; case 8:sum = 244;break;
		case 9: sum =274;break; case 10:sum = 305;break;
		case 11:sum = 335;break; case 12:sum = 366;break;
	}
	if(!Is_Run(year)){
			sum = sum-1;
	}
	return sum;
}
int main(){
	int y1,m1,d1,n,y2,m2,d2,x;
	int i,n_temp,sum = 0;
//	scanf("y1:%d m1:%d d1:%d n:%d",&y1,&m1,&d1,&n);
	scanf("%d %d %d %d",&y1,&m1,&d1,&n);
	if(n<0||n>3000||n==3000){
		printf("the n must between 0 and 3000!");
		return 0;
	} 

	if(n<Sum(m1-1,y1)+d1){
		if(n>d1){
			n_temp = n - d1;
			for(i=m1-1;i>=1;i--){
				sum += Day(i,y1);
				if(sum>n_temp) break;
			}
			y2 = y1;
			m2 = i;
			d2 = sum - n_temp;
		}
		else if(n==d1){
			y2 = y1;
			m2 = m1-1;
			d2 = Day(m2,y2);
		}
		else{
			y2 = y1;
			m2 = m1;
			d2 = d1-n;
		}
	}
	else if(n == Sum(m1-1,y1)+d1){
		y2 = y1-1;
		m2 = 12;
		d2 = 31;
	}
	else{
		int y_temp = y1;
		n_temp =n - (Sum(m1-1,y1)+d1);
		sum = 0;
		int j;
		for(i=0;i<9;i++){
			y_temp--;
			for(j=12;j>=1;j--){
				sum += Day(j,y_temp);
				if(sum>n_temp)break;
			}
	        if(sum>n_temp)break;		
		}
		y2 = y_temp;
		m2 = j;
		d2 = sum - n_temp;
	}
	if(m2==1||m2==1){
		int y2_temp = y2-1;
		if(m2==1){
			int m2_temp=13;
			x = (d2 + 1 + 2*m2_temp + 3*(m2_temp + 1)/5 + y2_temp + y2_temp/4 - y2_temp/100 + y2_temp/400)%7;
		}
		else{
			int m2_temp=14;
			x = (d2 + 1 + 2*m2_temp + 3*(m2_temp + 1)/5 + y2_temp +y2_temp/4 - y2_temp/100 + y2_temp/400)%7;
		}
	}
	else{
		x = (d2 + 1 + 2*m2 + 3*(m2 + 1)/5 + y2 + y2/4 - y2/100 + y2/400) % 7;
	}
	printf("%d %d %d %d\n",y2,m2,d2,x);
	
}
