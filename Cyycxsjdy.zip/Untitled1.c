#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Students {
//    ׼��֤��
    char num[9];
//    �·�
    int de;
//    �ŷ�
    int cai;
} Student;

int cmp(const void *a, const void *b) {
    Student A = *(Student *) a;
    Student B = *(Student *) b;

//    ���ܷ���ͬ���ٱȽϵ·�
    if (B.de + B.cai == A.de + A.cai) {
//        ���·���ͬ����׼��֤������
        if (B.de == A.de) {
            return strcmp(A.num, B.num);
        } else {
            return B.de - A.de;
        }
    } else {
        return (B.de + B.cai) - (A.de + A.cai);
    }
}

int main() {
    int N, L, H;
    scanf("%d %d %d", &N, &L, &H);
    Student student1[N + 1];
    Student student2[N + 1];
    Student student3[N + 1];
    Student student4[N + 1];
    int index1 = 0;
    int index2 = 0;
    int index3 = 0;
    int index4 = 0;
    char num[9];
    int de;
    int cai;
    

    for (int i = 0; i < N; i++) {
        scanf("%s %d %d", num, &de, &cai);
        if (de < L || cai < L) {
            continue;
        } else if (de >= H && cai >= H) {
            strcpy(student1[index1].num, num);
            student1[index1].de = de;
            student1[index1].cai = cai;
            index1++;
        } else if (de >= H) {
            strcpy(student2[index2].num, num);
            student2[index2].de = de;
            student2[index2].cai = cai;
            index2++;
        } else if (de >= cai) {
            strcpy(student3[index3].num, num);
            student3[index3].de = de;
            student3[index3].cai = cai;
            index3++;
        } else {
            strcpy(student4[index4].num, num);
            student4[index4].de = de;
            student4[index4].cai = cai;
            index4++;
        }
    }

    qsort(student1, index1, sizeof(student1[0]), cmp);
    qsort(student2, index2, sizeof(student2[0]), cmp);
    qsort(student3, index3, sizeof(student3[0]), cmp);
    qsort(student4, index4, sizeof(student4[0]), cmp);

    printf("%d\n", index1 + index2 + index3 + index4);
    for (int j = 0; j < index1; j++) {
        printf("%s %d %d\n", student1[j].num, student1[j].de, student1[j].cai);
    }
    for (int j = 0; j < index2; j++) {
        printf("%s %d %d\n", student2[j].num, student2[j].de, student2[j].cai);
    }
    for (int j = 0; j < index3; j++) {
        printf("%s %d %d\n", student3[j].num, student3[j].de, student3[j].cai);
    }
    for (int j = 0; j < index4; j++) {
        printf("%s %d %d\n", student4[j].num, student4[j].de, student4[j].cai);
    }

    return 0;
}
