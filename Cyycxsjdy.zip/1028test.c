#include <stdio.h>

struct Birthday {
    char name[6];
    int year;
    int month;
    int day;
};

int compareOld(struct Birthday a, struct Birthday b);


//ע�⣬��Ч����������Ϊ0
int main() {
    int N;
    scanf("%d", &N);

    int valueNo = 0;
    struct Birthday oldest;
    struct Birthday youngest;

    struct Birthday today = {"name", 2014, 9, 6};
    struct Birthday early = {"name", 1814, 9, 6};

    for (int i = 0; i < N; i++) {
        struct Birthday person;
        scanf("%s %d/%d/%d", person.name, &person.year, &person.month, &person.day);
        if (compareOld(person, today) && compareOld(early, person)) {
            if (!valueNo) {
                oldest = person;
                youngest = person;
            } else if (valueNo) {
                if (compareOld(person, oldest)) {
                    oldest = person;
                }

                if (compareOld(youngest, person)) {
                    youngest = person;
                }
            }

            valueNo++;
        }
    }
    if (valueNo) {
        printf("%d %s %s", valueNo, oldest.name, youngest.name);
    } else {
        printf("0");
    }

    return 0;
}

int compareOld(struct Birthday a, struct Birthday b) {
    if (a.year < b.year) {
        return 1;
    } else if (a.year == b.year && a.month < b.month) {
        return 1;
    } else if (a.year == b.year && a.month == b.month && a.day <= b.day) {
        return 1;
    }

    return 0;
}
