#include<stdio.h>
int Callatz(int n){
	if(n%2 ==0){
		n /= 2;
	}
	else{
		n = (3*n+1)/2;
	}
	return n;
}
void Bresort(int*a,int n){
	int i,j,temp;
	for(i=0;i<n;i++){    //����i�����Ƚϵ�����
        for(j=i;j<n-1;j++){    //����j����ÿ�������ȽϵĴ���
            if(a[j]<a[j+1]){
                temp=a[j];    //�����м����ʵ����ֵ����
                a[j]=a[j+1];
                a[j+1]=temp;
            }
    	}
    }
}
int main(){
	int m[100]={0};
	int c[100]={0};
	int n,i,j,p,k=0,sum=0;
	int n_temp;
	scanf("%d", &n);
	for(i=0;i<n;i++){
		scanf("%d",&c[i]);
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(i==j){;
			}
			else{
				n_temp = c[j];
				while(n_temp != 1){
					n_temp = Callatz(n_temp);
					if(n_temp==c[i]){
						p=0;
						break;
					}
					else{
						p=1;
					} 
				}
			}
			if(p==0){
				break;
			}
			else{
				;
			}
		}
		if(p == 1 ){
			m[k] = c[i];
			k++;
		}
	}
	for(i=0;i<n;i++){
		if(m[i]!=0){
			sum++;
		}
	}
	Bresort(m,sum);
	if(sum==1){
		printf("%d",m[0]);
	}
	else{
		for(i=0;i<sum-1;i++){
		printf("%d ",m[i]);
    	}
    	printf("%d",m[sum-1]);
	}	
	return 0;
}
	

