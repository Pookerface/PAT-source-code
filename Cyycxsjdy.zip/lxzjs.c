/*��Щ���������Ա�ʾΪn(n>1)������������֮��*/
#include<stdio.h>
int main(){
	int s,t;
	int i,sum=0,n=0,num=0;
	scanf("%d %d",&s,&t);
	for(i=1; i<s; i += 2){
		sum += i;
		n++;
		if(n==t){
			if(sum != s){
				n    = t-1;
				sum  -= i-2*(t-1);
			}
			else if(sum == s){
				num++;
				printf("%d=",s);
				int j;
				for(j=i-2*(t-1); j < i; j += 2){
					printf("%d+",j);
				}
				printf("%d\n",i);
				sum  -= i-2*(t-1);
				n = 0;
			}
			else ;
		}
	}
	if(num==0){
		printf("NONE");
	}
	return 0;
} 
