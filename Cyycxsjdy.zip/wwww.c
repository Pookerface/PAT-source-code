#include<stdio.h>
int main()
{
	printf("wwwwww");
	return 0;
}
