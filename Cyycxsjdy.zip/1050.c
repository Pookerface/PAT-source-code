#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int cmp(const void*a,const void*b){
	return *(int *)b-*(int *)a;
}
int main(){
	int N;
	scanf("%d",&N);
	int num[N];
	int m,n,max,len;
	len = abs(1-N/1);
	for(int i = 0;i<N;i++){
		scanf("%d",&num[i]);
		if(i>1&&N%i==0){
			if(abs(i-N/i)<len){
				n = i;
				m = N/i;
				len = abs(m-n);
			}
		}
	}
	if(m<n){
		int temp = m;
		m = n;
		n = temp;
	}
    qsort(num,N,sizeof(num[0]),cmp);
    int arr[m][n];
    int times = m/2+m%2;
    int k=0;
    for(int i = 0;i<times;i++){
    	//�� 
    	for(int j = i;k<N&&j<n-i;j++){
    		arr[i][j] = num[k++];
		}
		//�� 
		for(int j = i+1;k<N&&j<n-i-1;j--){
			arr[j][n-i-1] = num[k++];
		}
		//��
		for(int j = n-i-1;k<N&&j>=i;j--){
			arr[n-i-1][j] = num[k++];
		} 
		//��
		for(int j = m-i-2;k<N&&j>=i;j--){
			arr[j][i] = num[k++];
		} 
	}
	for (int i = 0; i < m; i++) {
    	for (int j = 0; j < n; j++) {
            printf("%d", arr[i][j]);
            if (j == n - 1 && i != m - 1) {
                printf("\n");
            } 
			else if (j != m - 1) {
                printf(" ");
            }
        }
    }
	return 0;
}
