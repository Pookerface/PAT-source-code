#include<stdio.h>
void draw_line(int st,int len,int c1,int c2)
{
	int i;
	for(i=0;i<st-1;i++)
		putchar(' ');
	putchar(c1);
	for(i=1;i<len-1;i++)
		putchar(c2);
	putchar(c1);
	putchar('\n'); 
 } 
 
 void triangle(int hi,int c1,int c2)
 {
 	int i,j;
 	for(i=0;  i<hi-1; i++)
 		putchar(' ');
 	putchar(c1);
 	putchar('\n');
 	for(i=1; i<hi-1; i++)
 		draw_line(hi-i,i*2+1,c1,c2);
 	for(j=0; j<hi*2-1; j++)
 		putchar(c1);
 	putchar('\n');
 }
 
 int main()
 {
 	int h,c1,c2;
 	scanf("%d %c %c",&h,&c1,&c2);
 	if(h<3||h>40){
 		printf("The height must be between 3 and 40\n");
 		return 1;
	 }
	triangle(h,c1,c2);
	return 0;
 }
