#include<stdio.h>
#include<string.h>
#define N 10
int main(){
//	int n,i=0;
////	int min,max;
//	int s;
//	char xm_min[N+1],xm_max[N+1],xh_min[N+1],xh_max[N+1];
//	scanf("%d",&n);
//	getchar();
	int n;
	char xx[2*N+1];
	scanf("%[A-Za-z A-Za-z0-9] %d",xx,&n);
	printf("%s\n",xx);
	return 0;
}
