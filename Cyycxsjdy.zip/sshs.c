#include<stdio.h>
int main(){
	char T,T1;
	int m,n;
	double m1,n1;
	scanf("<%c> <%d> <%d>",&T,&m,&n);
	if(T == 'F'){
		T1='C';
		m1 = (m-32)*5.0/9.0;
		n1 = (n-32)*5.0/9.0;
	}
	else{
		T1 = 'F';
		m1 = (m*9.0)/5.0+32;
		n1 = (n*9.0)/5.0+32;
	}
	printf("<%c> <%d> <%d>\t<%c><%3.1f><%3.1f>\n",T,m,n,T1,m1,n1);
	return 0;
}
